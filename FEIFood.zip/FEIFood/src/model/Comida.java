/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


public class Comida extends Alimento{

    public Comida() {
    }

    public Comida(int idAlimento, String nome, String descricao, String categoria, String tipo, double preco) {
        super(idAlimento, nome, descricao, categoria, tipo, preco);
    }
    
}
